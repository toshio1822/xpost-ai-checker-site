---
title: お問い合わせ・依頼フォーム｜XPost AI Checker
description: X（Twitter）誹謗中傷のAI分析・証拠PDF作成のご依頼・ご相談はこちら。Googleフォームまたはメールで受付。
---
# お問い合わせ / 依頼フォーム

ご依頼・ご相談は以下のフォームからどうぞ。

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSc0SEgMsh9yoKHw1Y4PBJgEC1oiF_PP7rGt0bf8cvwsoNeW5Q/viewform?usp=header"
        width="100%" height="1200" frameborder="0" marginheight="0" marginwidth="0">
読み込み中…
</iframe>

---

📩 **メール**： support@xpostaichecker.jp
